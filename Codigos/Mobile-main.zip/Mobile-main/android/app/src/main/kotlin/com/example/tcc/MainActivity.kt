package com.example.tcc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
