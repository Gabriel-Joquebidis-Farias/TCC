import 'package:flutter/material.dart';

class espaco extends StatelessWidget {
  const espaco({super.key});
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 10,
    );
  }
}
